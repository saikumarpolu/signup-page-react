import React from "react";

const AuthenticatedRoute = () => {
  return <div>AuthenticatedRoute</div>;
};

export default AuthenticatedRoute;
